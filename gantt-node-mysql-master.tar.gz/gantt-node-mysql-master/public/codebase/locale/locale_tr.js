/*
@license

dhtmlxGantt v.4.0.0 Stardard
This software is covered by GPL license. You also can obtain Commercial or Enterprise license to use it in non-GPL project - please contact sales@dhtmlx.com. Usage without proper license is prohibited.

(c) Dinamenta, UAB.
*/
gantt.locale={date:{month_full:["Ocak","Þubat","Mart","Nisan","Mayýs","Haziran","Temmuz","Aðustos","Eylül","Ekim","Kasým","Aralýk"],month_short:["Oca","Þub","Mar","Nis","May","Haz","Tem","Aðu","Eyl","Eki","Kas","Ara"],day_full:["Pazar","Pazartes,","Salý","Çarþamba","Perþembe","Cuma","Cumartesi"],day_short:["Paz","Pts","Sal","Çar","Per","Cum","Cts"]},labels:{dhx_cal_today_button:"Bugün",day_tab:"Gün",week_tab:"Hafta",month_tab:"Ay",new_event:"Uygun",icon_save:"Kaydet",icon_cancel:"Ýptal",icon_details:"Detaylar",
icon_edit:"Düzenle",icon_delete:"Sil",confirm_closing:"",confirm_deleting:"Etkinlik silinecek, devam?",section_description:"Açýklama",section_time:"Zaman aralýðý",section_type:"Type",column_text:"Task name",column_start_date:"Start time",column_duration:"Duration",column_add:"",link:"Link",confirm_link_deleting:"will be deleted",link_start:" (start)",link_end:" (end)",type_task:"Task",type_project:"Project",type_milestone:"Milestone",minutes:"Minutes",hours:"Hours",days:"Days",weeks:"Week",months:"Months",
years:"Years"}};
//# sourceMappingURL=../sources/locale/locale_tr.js.map